<div id="application-form" class="content">

<div class="row g-5">
    <div class="col-sm-12">
        <h1 class="fs-1 fw-bold text-black">Thank you for providing the requested information.</h1>
        <h3 class="text-black">Please use the link below to print the pre-filled application form.
        <!-- <button class="btn btn-primary btn-lg " onclick="printForm()"><i class="uil uil-print"></i> &nbsp;Print </button> -->
        </h3>
    </div>

</div>
</div>