<?php
if (isset($_POST['id']) && isset($_POST['by'])) {
    session_start();
    require '../../includes/db-config.php';
    echo $by = $_POST['by'];
    echo $id = intval($_POST['id']);
    $sub_center_name = "";
    // if ($by == 'session_data') {
    //     $_SESSION['filterBysession_data'] = " AND Students.Admission_Session_ID = $id";
    // } 
    if ($by == 'sub_courses') {
        $_SESSION['filterBySubCourses'] = " AND Students.Sub_Course_ID = $id";
    } elseif ($by == 'users') {
        $user = $conn->query("SELECT Role FROM Users WHERE ID = $id")->fetch_assoc();
        $role = $user['Role'];
        $role_query = " AND Students.Added_For = $id";
    }
    // $_SESSION['filterByUser'] = " AND Students.Added_For =$id";
    elseif ($by == 'search_assign_fee') {
        $get_ledger_stu_data = $conn->query("SELECT Student_ID FROM Student_Ledgers WHERE University_ID = '" . $_SESSION['University_ID'] . "' GROUP BY Student_ID");
        $stu_ledger_id_arr = [];
        while ($stu_ledger_id = $get_ledger_stu_data->fetch_assoc()) {
            $stu_ledger_id_arr[] = $stu_ledger_id['Student_ID'];
        }
        $fee_alloted_ids = implode(',', $stu_ledger_id_arr);
        if ($id == 1) {
            $_SESSION['filterByFeeAssigned'] = "AND Students.ID IN (" . $fee_alloted_ids . ")";
        } else {
            $_SESSION['filterByFeeAssigned'] = "AND Students.ID NOT IN (" . $fee_alloted_ids . ")";
        }
    }
    echo json_encode(['status' => true, 'subCenterName' => $sub_center_name]);
}
